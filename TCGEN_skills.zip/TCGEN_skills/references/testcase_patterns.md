# Testcase代码模式参考

> **命名规则**：所有class名中的 `<tc_name>` 必须严格使用Excel "DV Testcase List" sheet中 "TC Name" 列的值。seq class命名遵循现有TB惯例（从已有seq提取prefix），test class命名无前缀 `test_<tc_name>`。

> **文件组织**：所有新seq class追加到步骤3识别的seq package文件的 `endpackage` 之前，所有新test class追加到test package文件的 `endpackage` 之前。不创建独立文件或package。

> **占位符说明**：以下模板中 `<prefix>` 为从已有seq命名提取的前缀，`<base_seq>` 为基类seq，`<base_test>` 为基类test，`<txn_type>` 为transaction类型，`<sequencer_path>` 为sequencer实例路径，`<vif_type>` 为VIF接口类型，`<vif_name>` 为VIF在config_db中的名称——这些均在步骤3中从TB动态提取。所有 `<cmd_field>`、`<addr_field>`、`<data_field>` 等txn字段名均从步骤3的txn解析和步骤4的命令→字段映射表动态获得。

---

## 0. 代码生成核心规则

以下规则适用于所有seq和test的生成，不重复写在每个模式中。

### Sequence核心规则

- 绕过txn内建约束用 `txn.constraint_mode(0)`（构造非法值时必须）
- 数组字段大小须与对应长度字段匹配
- 不使用`uvm_do`宏，显式start_item/finish_item
- rand字段声明在new之前，constraint在rand之后
- new函数紧跟factory注册宏
- 字段设置顺序：命令字段 → 地址/寄存器 → 数据 → 配置 → 标志位

### 结果验证核心规则（强制）

**每条TC描述的"期望结果"必须有对应检查代码，不可只有激励无验证。**

在seq body中，每个 `finish_item(txn)` 之后，根据TC描述的期望结果添加检查：

```systemverilog
// 1. status检查（几乎所有TC都需要）
if (txn.status != <expected_status>) begin
    `uvm_error("TC_CHECK", $sformatf("Expected status=0x%02h, got 0x%02h", <expected_status>, txn.status))
end

// 2. rdata检查（读命令需要）
if (txn.rdata.size() > 0 && txn.rdata[0] !== <expected_data>) begin
    `uvm_error("TC_CHECK", $sformatf("Expected rdata[0]=0x%08h, got 0x%08h", <expected_data>, txn.rdata[0]))
end

// 3. 多beat rdata检查（burst读需要）
foreach (txn.rdata[i]) begin
    if (txn.rdata[i] !== <expected_data_i>) begin
        `uvm_error("TC_CHECK", $sformatf("rdata[%0d]: expected=0x%08h, got=0x%08h", i, <expected_data_i>, txn.rdata[i]))
    end
end
```

**错误注入类TC的特殊规则**：
- 错误响应只返回8-bit status，无rdata → `txn.has_rdata = 0`
- 此时只检查 `txn.status`，不检查rdata

### 时序核心规则

- **时序延迟用VIF周期计数**：`repeat(N) @(m_vif.cb)`，不用固定 `#delay`，除非TC明确要求绝对时间
- **等待条件用VIF信号**：`wait(m_vif.<signal> === <value>)`，不用固定延迟替代
- seq中需要VIF时，在body开头通过config_db获取

### Test核心规则

- 修改agent config必须在build_phase中super之后
- 复位操作使用base_test提供的helper task
- **package中不得使用层次引用**
- VIF操作通过config_db获取，不用层次路径
- 启动seq前调用randomize
- 使用factory实例化，不用直接new

---

## 1. 基本功能测试模式

### 1.1 单命令测试（复用已有sequence）

适用：各配置下的单个命令测试

**seq** — 无需新建seq，直接复用已有的基本seq

**test class**：
```systemverilog
class test_<tc_name> extends <base_test>;
    `uvm_component_utils(test_<tc_name>)

    function new(string name, uvm_component parent);
        super.new(name, parent);
    endfunction

    virtual task run_phase(uvm_phase phase);
        <prefix>_<existing_seq>_seq seq;
        seq = <prefix>_<existing_seq>_seq::type_id::create("seq");
        seq.param1 = value;  // 根据TC设置已有seq的参数
        seq.starting_phase = phase;
        seq.start(<sequencer_path>);
        // 注意：复用已有seq时，结果验证由seq内部或scoreboard完成
        // 如TC要求test层显式验证，需新建seq（见1.2）
    endtask
endclass
```

### 1.2 多配置遍历测试

适用：同一命令在不同配置下运行

**seq class**：
```systemverilog
class <prefix>_<tc_name>_seq extends <base_seq>;
    `uvm_object_utils(<prefix>_<tc_name>_seq)

    rand /* config字段类型 */ config_val;  // 按项目需求定义

    // 按项目映射表定义约束
    constraint c_config { /* 配置范围 */ }

    function new(string name = "<prefix>_<tc_name>_seq");
        super.new(name);
    endfunction

    virtual task body();
        <txn_type> txn;
        txn = <txn_type>::type_id::create("txn");
        // 按项目映射表设置txn字段
        start_item(txn);
        finish_item(txn);
        // 结果验证（按TC期望结果）
        if (txn.status != <expected_status>) begin
            `uvm_error("TC_CHECK", $sformatf("Expected status=0x%02h, got 0x%02h", <expected_status>, txn.status))
        end
    endtask
endclass
```

---

## 2. 错误注入测试模式

### 2.1 非法命令测试

适用：发送DUT不支持的命令编码

**seq class**：
```systemverilog
class <prefix>_<tc_name>_seq extends <base_seq>;
    `uvm_object_utils(<prefix>_<tc_name>_seq)

    // 按项目需求声明rand字段

    function new(string name = "<prefix>_<tc_name>_seq");
        super.new(name);
    endfunction

    virtual task body();
        <txn_type> txn;
        txn = <txn_type>::type_id::create("txn");
        txn.constraint_mode(0);  // 关闭所有内建约束
        // 按项目映射表设置非法命令编码
        // 错误注入时has_rdata=0，错误响应只返回status
        start_item(txn);
        finish_item(txn);
        // 错误响应验证
        if (txn.status != <expected_error_status>) begin
            `uvm_error("TC_CHECK", $sformatf("Expected error status=0x%02h, got 0x%02h", <expected_error_status>, txn.status))
        end
    endtask
endclass
```

### 2.2 非法地址测试

适用：访问DUT地址范围之外的区域

**seq class**：
```systemverilog
class <prefix>_<tc_name>_seq extends <base_seq>;
    `uvm_object_utils(<prefix>_<tc_name>_seq)

    rand /* addr字段类型 */ addr;
    // 按项目需求声明其他rand字段

    constraint c_bad_addr { /* 非法地址范围，按项目定义 */ }

    function new(string name = "<prefix>_<tc_name>_seq");
        super.new(name);
    endfunction

    virtual task body();
        <txn_type> txn;
        txn = <txn_type>::type_id::create("txn");
        txn.constraint_mode(0);
        // 按项目映射表设置字段
        // 错误注入时has_rdata=0
        start_item(txn);
        finish_item(txn);
        // 错误响应验证
        if (txn.status != <expected_error_status>) begin
            `uvm_error("TC_CHECK", $sformatf("Expected error status=0x%02h, got 0x%02h", <expected_error_status>, txn.status))
        end
    endtask
endclass
```

### 2.3 非对齐地址测试

适用：地址未按协议要求对齐

**seq class**：
```systemverilog
class <prefix>_<tc_name>_seq extends <base_seq>;
    `uvm_object_utils(<prefix>_<tc_name>_seq)

    rand /* addr字段类型 */ addr;
    // 按项目需求声明其他rand字段

    constraint c_misalign { /* 非对齐条件，按项目对齐规则 */ }

    function new(string name = "<prefix>_<tc_name>_seq");
        super.new(name);
    endfunction

    virtual task body();
        <txn_type> txn;
        txn = <txn_type>::type_id::create("txn");
        txn.constraint_mode(0);
        // 按项目映射表设置字段
        start_item(txn);
        finish_item(txn);
    endtask
endclass
```

### 2.4 非法长度测试

适用：burst/传输长度不在合法值范围内

**seq class**：
```systemverilog
class <prefix>_<tc_name>_seq extends <base_seq>;
    `uvm_object_utils(<prefix>_<tc_name>_seq)

    rand /* len字段类型 */ burst_len;
    rand /* addr字段类型 */ addr;
    // 按项目需求声明其他rand字段

    constraint c_bad_len { /* 非法长度，按项目合法值取反 */ }

    function new(string name = "<prefix>_<tc_name>_seq");
        super.new(name);
    endfunction

    virtual task body();
        <txn_type> txn;
        txn = <txn_type>::type_id::create("txn");
        txn.constraint_mode(0);
        // 按项目映射表设置字段
        start_item(txn);
        finish_item(txn);
    endtask
endclass
```

---

## 3. 总线错误/延迟测试模式

### 3.1 总线error injection

适用：总线返回错误响应

**test class**（seq复用已有的write seq）：
```systemverilog
class test_<tc_name> extends <base_test>;
    `uvm_component_utils(test_<tc_name>)

    function new(string name, uvm_component parent);
        super.new(name, parent);
    endfunction

    virtual function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        <bus_cfg>.error_inject   = 1'b1;
        <bus_cfg>.error_beat_idx = 0;  // 按TC设置
    endfunction

    virtual task run_phase(uvm_phase phase);
        // 复用已有seq，按TC设置参数
    endtask
endclass
```

### 3.2 总线delay/backpressure

适用：制造总线延迟或反压

**test class**：
```systemverilog
class test_<tc_name> extends <base_test>;
    `uvm_component_utils(test_<tc_name>)

    function new(string name, uvm_component parent);
        super.new(name, parent);
    endfunction

    virtual function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        <bus_cfg>.default_delay = 10;  // 按TC设置延迟周期
    endfunction

    virtual task run_phase(uvm_phase phase);
        for (int i = 0; i < 8; i++) begin
            <prefix>_<burst_seq>_seq seq;
            seq = <prefix>_<burst_seq>_seq::type_id::create($sformatf("seq_%0d", i));
            // 按TC设置参数
            seq.starting_phase = phase;
            seq.start(<sequencer_path>);
        end
    endtask
endclass
```

---

## 4. 配置/模式测试模式

### 4.1 使能/模式拒绝测试

适用：DUT在特定配置下应拒绝操作

**test class**（seq复用已有）：
```systemverilog
class test_<tc_name> extends <base_test>;
    `uvm_component_utils(test_<tc_name>)

    function new(string name, uvm_component parent);
        super.new(name, parent);
    endfunction

    virtual task run_phase(uvm_phase phase);
        // 通过VIF设置禁止条件（信号名从步骤3 VIF信号列表提取）
        <vif_path>.<enable_signal> <= 1'b0;
        // 复用已有seq发送命令
    endtask
endclass
```

### 4.2 配置空间属性验证测试

适用：验证配置空间的只读/读写/写1清0等属性

**seq class**：
```systemverilog
class <prefix>_<tc_name>_seq extends <base_seq>;
    `uvm_object_utils(<prefix>_<tc_name>_seq)

    // 按项目需求声明rand字段

    function new(string name = "<prefix>_<tc_name>_seq");
        super.new(name);
    endfunction

    virtual task body();
        <txn_type> wr_txn, rd_txn;

        // Write to RO space - should be ignored
        wr_txn = <txn_type>::type_id::create("wr_txn");
        // 按项目映射表设置：命令=write, 地址=RO区域, 数据=测试值
        // 按TB限制设置响应相关字段
        start_item(wr_txn); finish_item(wr_txn);

        // Read back RO space - should be unchanged
        rd_txn = <txn_type>::type_id::create("rd_txn");
        // 按项目映射表设置：命令=read, 地址=RO区域
        // 按TB限制设置响应相关字段
        start_item(rd_txn); finish_item(rd_txn);

        // Write to WC space - write-1-clear
        wr_txn = <txn_type>::type_id::create("wr_wc_txn");
        // 按项目映射表设置：命令=write, 地址=WC区域, 数据=1
        // 按TB限制设置响应相关字段
        start_item(wr_txn); finish_item(wr_txn);
    endtask
endclass
```

---

## 5. 随机测试模式

### 5.1 带约束的随机sequence

适用：在合法范围内随机化测试

**seq class**：
```systemverilog
class <prefix>_<tc_name>_seq extends <base_seq>;
    `uvm_object_utils(<prefix>_<tc_name>_seq)

    // 按项目需求声明所有需要随机化的字段
    rand /* cmd字段类型 */   cmd;
    rand /* len字段类型 */   burst_len;
    rand /* addr字段类型 */  addr;
    rand /* data字段类型 */  wdata;
    // ... 其他字段

    // 按项目映射表定义约束
    constraint c_legal_cmd { cmd inside {/* 项目合法值 */}; }
    constraint c_legal_len { /* 按项目传输长度规则 */ }
    constraint c_align     { /* 按项目对齐规则 */ }
    constraint c_addr_range{ /* 按项目地址范围 */ }

    function new(string name = "<prefix>_<tc_name>_seq");
        super.new(name);
    endfunction

    virtual task body();
        <txn_type> txn;
        txn = <txn_type>::type_id::create("txn");
        // 按项目映射表设置字段
        start_item(txn);
        finish_item(txn);
    endtask
endclass
```

### 5.2 随机测试的test class（repeat多次）

**test class**：
```systemverilog
class test_<tc_name> extends <base_test>;
    `uvm_component_utils(test_<tc_name>)

    function new(string name, uvm_component parent);
        super.new(name, parent);
    endfunction

    virtual task run_phase(uvm_phase phase);
        for (int i = 0; i < 200; i++) begin
            <prefix>_<tc_name>_seq seq;
            seq = <prefix>_<tc_name>_seq::type_id::create($sformatf("seq_%0d", i));
            assert(seq.randomize());
            seq.starting_phase = phase;
            seq.start(<sequencer_path>);
        end
    endtask
endclass
```

---

## 6. 边界测试模式

适用：测试地址/长度/数据等的边界值

**seq class**：
```systemverilog
class <prefix>_<tc_name>_seq extends <base_seq>;
    `uvm_object_utils(<prefix>_<tc_name>_seq)

    // 按项目需求声明rand字段

    function new(string name = "<prefix>_<tc_name>_seq");
        super.new(name);
    endfunction

    virtual task body();
        <txn_type> txn;
        // 按项目边界规则计算边界值
        txn = <txn_type>::type_id::create("txn");
        txn.constraint_mode(0);
        // 按项目映射表设置字段
        start_item(txn);
        finish_item(txn);
    endtask
endclass
```

---

## 7. 多命令序列测试模式

适用：连续发送多个不同命令

**seq class**：
```systemverilog
class <prefix>_<tc_name>_seq extends <base_seq>;
    `uvm_object_utils(<prefix>_<tc_name>_seq)

    rand int num_cmds;

    constraint c_num { num_cmds inside {[2:10]}; }

    function new(string name = "<prefix>_<tc_name>_seq");
        super.new(name);
    endfunction

    virtual task body();
        for (int i = 0; i < num_cmds; i++) begin
            <txn_type> txn;
            txn = <txn_type>::type_id::create($sformatf("txn_%0d", i));
            // 按TC描述交替设置不同命令
            start_item(txn);
            finish_item(txn);
        end
    endtask
endclass
```

---

## 8. 状态检查/轮询测试模式

适用：触发错误后轮询状态寄存器

**seq class**：
```systemverilog
class <prefix>_<tc_name>_seq extends <base_seq>;
    `uvm_object_utils(<prefix>_<tc_name>_seq)

    function new(string name = "<prefix>_<tc_name>_seq");
        super.new(name);
    endfunction

    virtual task body();
        <txn_type> txn;

        // Step 1: Trigger an error
        txn = <txn_type>::type_id::create("err_txn");
        txn.constraint_mode(0);
        // 按项目映射表设置错误触发条件
        start_item(txn); finish_item(txn);

        // Step 2: Read status register
        txn = <txn_type>::type_id::create("poll_txn");
        // 按项目映射表设置：命令=read, 地址=状态空间
        start_item(txn); finish_item(txn);

        // Step 3: Read error code register
        txn = <txn_type>::type_id::create("last_err_txn");
        // 按项目映射表设置：命令=read, 地址=错误码空间
        start_item(txn); finish_item(txn);
    endtask
endclass
```

---

## 9. 协议帧中止模式

适用：TC要求提前终止协议帧传输

**seq class**：
```systemverilog
class <prefix>_<tc_name>_seq extends <base_seq>;
    `uvm_object_utils(<prefix>_<tc_name>_seq)

    function new(string name = "<prefix>_<tc_name>_seq");
        super.new(name);
    endfunction

    virtual task body();
        virtual <vif_type> vif;
        <txn_type> txn;

        // 获取VIF（信号名从步骤3 VIF信号列表提取）
        if (!uvm_config_db #(virtual <vif_type>)::get(null, "", "<vif_name>", vif))
            `uvm_error("NOVIF", "Cannot get <vif_name>")

        // 构造txn并发送部分帧
        txn = <txn_type>::type_id::create("txn");
        // 按项目映射表设置字段
        // 手动驱动部分帧数据（信号名从VIF提取）
        vif.<frame_select_signal> <= 1'b0;  // 选中从设备
        vif.<frame_data_signal>   <= /* 部分帧数据 */;
        @(vif.cb);

        // Abort: 提前释放选中信号
        vif.<frame_select_signal> <= 1'b1;
        vif.<frame_data_signal>   <= '0;

        // 等待响应（期望错误状态码）
        // ...
    endtask
endclass
```

---

## 10. 配置切换模式

适用：运行中切换DUT配置（如位宽模式、工作模式等）

**seq class**：
```systemverilog
class <prefix>_<tc_name>_seq extends <base_seq>;
    `uvm_object_utils(<prefix>_<tc_name>_seq)

    function new(string name = "<prefix>_<tc_name>_seq");
        super.new(name);
    endfunction

    virtual task body();
        virtual <vif_type> vif;

        // 获取VIF
        if (!uvm_config_db #(virtual <vif_type>)::get(null, "", "<vif_name>", vif))
            `uvm_error("NOVIF", "Cannot get <vif_name>")

        // 发送第一个事务（配置A）
        <txn_type> txn1;
        txn1 = <txn_type>::type_id::create("txn1");
        // 按项目映射表设置字段（配置A）
        start_item(txn1); finish_item(txn1);

        // 切换配置（信号名从VIF提取）
        vif.<config_signal> <= /* 配置B的值 */;

        // 发送第二个事务（配置B）
        <txn_type> txn2;
        txn2 = <txn_type>::type_id::create("txn2");
        // 按项目映射表设置字段（配置B）
        start_item(txn2); finish_item(txn2);
    endtask
endclass
```

---

## 11. 运行中复位模式

适用：在事务执行过程中插入复位

**test class**：
```systemverilog
class test_<tc_name> extends <base_test>;
    `uvm_component_utils(test_<tc_name>)

    function new(string name, uvm_component parent);
        super.new(name, parent);
    endfunction

    virtual task run_phase(uvm_phase phase);
        fork
            begin
                <prefix>_<seq_name>_seq seq;
                seq = <prefix>_<seq_name>_seq::type_id::create("seq");
                seq.starting_phase = phase;
                seq.start(<sequencer_path>);
            end
            begin
                // 延迟后插入复位
                #<delay>;
                apply_reset();  // base_test helper task
            end
        join_any
        disable fork;
    endtask
endclass
```
