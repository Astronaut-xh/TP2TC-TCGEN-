# TC Mapping Table

| TC ID | TC Name | Seq Class | Test Class |
|-------|---------|-----------|------------|
| TC_001 | test_clk_stability | aplc_test_clk_stability_seq | test_clk_stability |
