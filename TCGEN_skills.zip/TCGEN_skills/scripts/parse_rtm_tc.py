#!/usr/bin/env python3
"""
RTM Excel "DV Testcase List" sheet parser.

Usage:
    python3 parse_rtm_tc.py <excel_path> [options]

Options:
    --sheet NAME       Sheet name (default: "DV Testcase List")
    --output PATH      Output JSON path (default: parsed_testcases.json)

Generic assumptions:
    - Header row is auto-detected by searching for "TC" keyword in column A
    - 4 columns: TC编号, TC Name, TC描述, 备注 (column order fixed, header names flexible)
    - Data ends at first row where column A is empty

Output format (parsed_testcases.json):
    [
        {
            "tc_id": "TC_001",
            "tc_name": "test_clk_stability",
            "tc_desc": "...",
            "tc_note": "..."
        },
        ...
    ]
"""

import openpyxl
import json
import argparse
import sys


def find_header_row(ws, max_search=10):
    """Auto-detect header row by searching for 'TC' in first column."""
    for i, row in enumerate(ws.iter_rows(min_row=1, max_row=max_search, values_only=True), 1):
        val = str(row[0]).strip() if row[0] is not None else ""
        if "TC" in val.upper() and "编号" in val:
            return i
    return None


def parse_tc_sheet(excel_path, sheet_name="DV Testcase List"):
    """Parse DV Testcase List sheet and return list of testcase dicts."""
    wb = openpyxl.load_workbook(excel_path, data_only=True)

    if sheet_name not in wb.sheetnames:
        print(f"Error: Sheet '{sheet_name}' not found. Available: {wb.sheetnames}")
        sys.exit(1)

    ws = wb[sheet_name]

    # Auto-detect header row
    header_row = find_header_row(ws)
    if header_row is None:
        print("Error: Cannot find header row (searching for 'TC编号' in column A)")
        sys.exit(1)

    data_start = header_row + 1
    print(f"Header row: {header_row}, data starts at row: {data_start}")

    # Parse data rows
    testcases = []
    for row in ws.iter_rows(min_row=data_start, values_only=True):
        tc_id = row[0]
        if tc_id is None:
            break
        testcases.append({
            "tc_id":   str(tc_id).strip(),
            "tc_name": str(row[1]).strip() if len(row) > 1 and row[1] is not None else "",
            "tc_desc": str(row[2]).strip() if len(row) > 2 and row[2] is not None else "",
            "tc_note": str(row[3]).strip() if len(row) > 3 and row[3] is not None else ""
        })

    return testcases


def main():
    parser = argparse.ArgumentParser(description="Parse RTM Excel DV Testcase List")
    parser.add_argument("excel", help="Path to RTM Excel file")
    parser.add_argument("--sheet", default="DV Testcase List", help="Sheet name (default: 'DV Testcase List')")
    parser.add_argument("--output", default="parsed_testcases.json", help="Output JSON path")
    args = parser.parse_args()

    testcases = parse_tc_sheet(args.excel, args.sheet)
    print(f"Parsed {len(testcases)} testcases")

    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(testcases, f, ensure_ascii=False, indent=2)
    print(f"Saved to {args.output}")


if __name__ == "__main__":
    main()
