#!/usr/bin/env python3
"""
RTM Excel "Checker List" sheet parser.

Usage:
    python3 parse_rtm_checker.py <excel_path> [options]

Options:
    --sheet NAME       Sheet name (default: "Checker List")
    --output PATH      Output JSON path (default: parsed_checkers.json)

Generic assumptions:
    - Header row is auto-detected by searching for "CHK" keyword in column A
    - Columns: CHK编号(A), CHK名称(B), CHK描述(C), 备注(D)
    - Column B/C names may be in merged cells (missing header is tolerated)
    - Data ends at first row where column A is empty

Output format (parsed_checkers.json):
    [
        {
            "chk_id": "CHK_001",
            "chk_name": "reset_state_checker",
            "chk_desc": "...",
            "chk_note": "..."
        },
        ...
    ]
"""

import openpyxl
import json
import argparse
import sys


def find_header_row(ws, max_search=10):
    """Auto-detect header row by searching for 'CHK' keyword in column A."""
    for i, row in enumerate(ws.iter_rows(min_row=1, max_row=max_search, values_only=True), 1):
        val = str(row[0]).strip() if row[0] is not None else ""
        if "CHK" in val.upper() and "编号" in val:
            return i
    # Fallback: search for any row with "CHK" in column A
    for i, row in enumerate(ws.iter_rows(min_row=1, max_row=max_search, values_only=True), 1):
        val = str(row[0]).strip() if row[0] is not None else ""
        if "CHK" in val.upper():
            return i
    return None


def parse_checker_sheet(excel_path, sheet_name="Checker List"):
    """Parse Checker List sheet and return list of checker dicts."""
    wb = openpyxl.load_workbook(excel_path, data_only=True)

    if sheet_name not in wb.sheetnames:
        print(f"Error: Sheet '{sheet_name}' not found. Available: {wb.sheetnames}")
        sys.exit(1)

    ws = wb[sheet_name]

    # Auto-detect header row
    header_row = find_header_row(ws)
    if header_row is None:
        print("Error: Cannot find header row (searching for 'CHK' in column A)")
        sys.exit(1)

    data_start = header_row + 1
    print(f"Header row: {header_row}, data starts at row: {data_start}")

    # Parse data rows
    checkers = []
    for row in ws.iter_rows(min_row=data_start, values_only=True):
        chk_id = row[0]
        if chk_id is None:
            break
        checkers.append({
            "chk_id":   str(chk_id).strip(),
            "chk_name": str(row[1]).strip() if len(row) > 1 and row[1] is not None else "",
            "chk_desc": str(row[2]).strip() if len(row) > 2 and row[2] is not None else "",
            "chk_note": str(row[3]).strip() if len(row) > 3 and row[3] is not None else ""
        })

    return checkers


def main():
    parser = argparse.ArgumentParser(description="Parse RTM Excel Checker List")
    parser.add_argument("excel", help="Path to RTM Excel file")
    parser.add_argument("--sheet", default="Checker List", help="Sheet name (default: 'Checker List')")
    parser.add_argument("--output", default="parsed_checkers.json", help="Output JSON path")
    args = parser.parse_args()

    checkers = parse_checker_sheet(args.excel, args.sheet)
    print(f"Parsed {len(checkers)} checkers")

    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(checkers, f, ensure_ascii=False, indent=2)
    print(f"Saved to {args.output}")


if __name__ == "__main__":
    main()
