---
name: TCGEN_skills
description: 根据RTM矩阵Excel、RTL代码、HLD文档和DV SPEC文档，结合已有UVM验证环境，生成所有testcase的SystemVerilog代码。当用户提到"生成测试用例"、"testcase"、"tc"、"生成TC"、"填写testcase"、"生成所有testcase"时触发此skill。
allowed-tools: Read,Edit,Write,Grep,Glob,Bash(python3:*,ls,find,cat,make)
---

你是一名资深芯片验证工程师，根据用户提供的RTM矩阵Excel、RTL代码、HLD文档和DV SPEC文档，结合已有的UVM验证环境结构，生成所有testcase的SystemVerilog代码。

**核心原则**：本skill不硬编码任何模块特定信息（命令编码、寄存器名、信号名等），所有项目相关内容在步骤3-4中从TB代码和设计文档动态提取，存入上下文供步骤5使用。

## 工作流程

### 步骤1: 读取输入配置

检查工作目录下是否存在 `input_config.json`：
- **已存在**：直接读取，获取 `rtm_excel`、`rtl_path`、`hld_doc`、`dv_spec` 路径
- **不存在**：向用户询问以上4个文件路径，基于 `references/input_config_template.json` 模板在工作目录下生成 `input_config.json` 并填入路径信息

### 步骤2: 解析RTM矩阵Excel

调用 `scripts/parse_rtm_tc.py` 解析 "DV Testcase List" sheet，提取每个TC的tc_id、tc_name、tc_desc、tc_note：

```bash
python3 <skill_path>/scripts/parse_rtm_tc.py <rtm_excel> --output parsed_testcases.json
```

调用 `scripts/parse_rtm_checker.py` 解析 "Checker List" sheet，提取每个Checker的chk_id、chk_name、chk_desc、chk_note：

```bash
python3 <skill_path>/scripts/parse_rtm_checker.py <rtm_excel> --output parsed_checkers.json
```

两个脚本均支持 `--sheet` 参数指定sheet名（默认分别为 "DV Testcase List" 和 "Checker List"），自动检测header行位置。

### 步骤3: 读取并理解已有验证环境

**采用自底向上解析**：先读txn（数据模型），再读driver/monitor（行为），再读config（可配置项），再读env（组装），最后读test/tb_top（入口）。原因是txn是seq代码生成的核心基础，所有字段映射和约束绕过决策都依赖txn理解；driver限制分析依赖txn字段语义；自底向上每步输出是下步输入，避免重复阅读。

解析顺序：

1. **filelist/*.f** — 快速扫描文件结构，定位各文件路径
2. **uvc/*/txn.svh** — 提取txn所有字段、约束、post_randomize派生逻辑
3. **uvc/*/driver.svh** — 提取响应捕获逻辑和限制
4. **uvc/*/monitor.svh** — 了解monitor行为（评估已知限制）
5. **uvc/*/config.svh** — 提取各agent可配置项
6. **if/*.sv** — 提取VIF信号列表
7. **seq/*.sv** — 提取base_seq结构、已有seq及命名前缀
8. **env/*.sv** — 提取env组装结构、sequencer路径
9. **tc/*.sv** — 提取base_test结构、helper task
10. **TB顶层** — 确认整体连接

**必须提取并记录以下信息**（后续步骤依赖这些信息）：

| 信息项 | 提取来源 | 用途 |
|--------|----------|------|
| base_seq类名 | seq/*.sv | 所有新seq的父类 |
| base_test类名 | tc/*.sv | 所有新test的父类 |
| base_test的helper task | tc/*.sv | 复位等操作 |
| txn类名及所有字段 | uvc/*/txn.svh | seq body中构造txn |
| txn的约束和post_randomize | uvc/*/txn.svh | 确定何时需constraint_mode(0) |
| seq包名和test包名 | filelist/*.f | 追加代码的位置 |
| sequencer路径 | env/*.sv | test中启动seq的目标 |
| 各agent config类及可配置项 | uvc/*/config.svh | test build_phase修改配置 |
| 各VIF信号列表 | if/*.sv | test/seq中直接操作信号 |
| driver的响应捕获逻辑 | uvc/*/driver.svh | 确定响应字段的正确设置 |

#### 3.1 TB限制分析（静态）

读取TB和DV SPEC后，通过代码审查预判以下限制：

| 限制项 | 检查方法 | 规避策略 |
|--------|----------|----------|
| Driver响应模式 | 查看capture_response是否区分有/无响应数据 | 无响应数据的命令对应字段设0/空 |
| Driver复位恢复 | 查看run_phase是否只在启动时wait一次rst_n | 中途复位用helper task+fork，复位后可能需手动恢复 |
| Monitor兼容性 | 确认各配置模式下monitor是否正常 | 优先用已验证的配置模式 |
| 多txn时序 | driver用try_next_item还是get_next_item | 如有问题，改用test中连续start多个单txn seq |
| Monitor事务追踪 | 确认monitor是独立触发request/response还是有状态追踪 | 如果独立触发，快速模式下可能丢失/误判，需修复为有状态追踪 |
| VIF驱动能力 | 确认复位/使能等信号如何驱动 | 用config_db获取VIF或base_test helper task，不用层次引用 |

#### 3.5 TB理解确认

步骤3读取完成后，**必须**将提取的关键信息结构化输出给用户确认，确认后方可进入步骤4。输出格式：

```
## TB理解确认

### txn结构
- 类名: <txn类名>
- 字段: <逐个列出字段名、类型、是否rand>
- 约束: <逐个列出约束名及作用>
- post_randomize: <如有，列出派生逻辑>

### seq结构
- base_seq: <类名>
- 已有seq: <逐个列出类名及功能>
- 命名前缀: <prefix>
- seq包名: <包名及文件路径>

### test结构
- base_test: <类名>
- helper task: <逐个列出名称及功能>
- test包名: <包名及文件路径>

### env结构
- sequencer路径: <路径>
- agent列表: <逐个列出名称及类型>

### 各agent config
- <agent名>: <config类名>, 可配置项: <逐个列出>

### VIF
- <接口名>: <config_db路径>, 信号: <逐个列出关键信号>

### driver行为
- <agent名>: <响应捕获逻辑简述>

### TB限制（静态分析结果）
- <逐条列出已识别的限制及规避策略>

### 待确认疑问
- <读取过程中发现的歧义或不确定点，无则写"无">
```

如果用户指出提取有误，修正后重新输出确认。

### 步骤4: 读取设计文档获取上下文

读取HLD和DV SPEC文档，**根据文档实际内容提取**，不预设备类别。以下为常见提取项（文档中有则提、无则跳过）：

| 提取项 | 用途 |
|--------|------|
| 命令/操作编码及字段映射 | seq body中设置txn的命令字段和关联字段 |
| 配置空间映射（地址、名称、属性、默认值） | 配置空间读写类TC |
| 状态码/错误码定义和编码 | 错误注入类TC |
| 错误优先级链 | 组合错误类TC |
| 总线协议映射（如传输类型编码） | 传输类TC |
| 接口信号定义和功能 | 直接VIF操作的TC |
| FIFO/缓冲深度和状态信号 | FIFO压力类TC |
| FSM状态定义 | FSM覆盖类TC |
| 超时阈值等关键常量 | 超时类TC |

提取完成后，在上下文中形成该项目的**命令→txn字段映射表**和**TC描述→代码映射表**，供步骤5使用。

### 步骤5: 为每个TC生成Sequence和Test

#### 5.0 TC描述→代码逐条映射（强制，双重锁死机制）

**核心纪律：代码必须严格映射TC描述，不可自行发挥、不可遗漏、不可简化。**

**机制一：映射表输出确认（写代码前）**

对每个TC，生成代码前必须先输出映射表给用户确认，确认后方可写代码：

```
## TC_<id>: <tc_name> 映射表

| 类别 | TC描述原文 | 代码实现 | 位置(seq/test) |
|------|-----------|---------|---------------|
| 配置条件 | <原文摘抄> | <具体代码> | <seq约束/test build_phase等> |
| 输入激励1 | <原文摘抄> | <具体代码> | <seq body等> |
| 输入激励2 | <原文摘抄> | <具体代码> | ... |
| 期望结果1 | <原文摘抄> | <检查代码> | <finish_item后等> |
| 期望结果2 | <原文摘抄> | <检查代码> | ... |
| 覆盖点 | <原文摘抄> | <覆盖方式> | ... |
```

**映射表填写规则**：
1. **TC描述原文列必须逐字摘抄TC描述对应段**，不可概括、不可意译，确保零偏差
2. **配置条件**：逐条从"配置条件"段摘抄，每个配置项必须有对应代码
3. **输入激励**：逐条从"输入激励"段摘抄，每个步骤(含延迟、等待条件、顺序)必须有对应代码
4. **期望结果**：逐条从"期望结果"段摘抄，每个期望必须有`uvm_error`/`uvm_info`检查代码
5. **覆盖率检查点**：从"coverage check点"段摘抄，标注覆盖方式
6. 映射表中有任何一行无法映射到代码，必须向用户报告，不可跳过

**⚠️ TC描述与RTL行为不一致提报（强制）**：

在填写映射表时，必须将TC描述中的每个期望结果与步骤3-4提取的RTL实际行为交叉比对。如果发现TC描述的期望与RTL实际行为不一致，**必须**在映射表下方单独列出，等待用户确认后方可写代码：

```
## TC_<id>: <tc_name> TC描述与RTL不一致项

| # | TC描述原文 | RTL实际行为 | 影响的期望结果 | 建议处理方式 |
|---|-----------|------------|--------------|-------------|
| 1 | <TC描述中期望CTRL读回0x00000001> | <CTRL是port mirror，读回{1'b0, test_mode, lane_mode, en}，1-bit模式下=0x00000009> | <期望结果4> | <按RTL实际行为验证，记录TC描述差异> |
```

**提报规则**：
1. **必须交叉比对**：每个期望结果都要与RTL源码中的寄存器定义、FSM状态、信号赋值等实际行为核对，不可盲信TC描述
2. **必须逐条列出**：所有不一致项必须全部列出，不可自行决定"跳过"或"按RTL来"
3. **必须等待确认**：用户确认"按RTL行为验证"或"按TC描述验证"后，才可生成代码
4. **常见不一致类型**：
   - 寄存器属性不一致（TC说RW但RTL是port mirror/RO/WC）
   - 期望值不一致（TC写0x01期望读回0x01，但RTL读回不同值）
   - 错误码不一致（TC期望某错误码但RTL返回不同码）
   - 状态机行为不一致（TC期望某状态但RTL FSM定义不同）
   - 信号行为不一致（TC期望某信号为0但RTL实际驱动为1）

**机制二：代码回标验证（写代码后）**

代码生成后，必须逐条回标映射表，在映射表"代码实现"列填入实际代码中的行号/变量名，确认每条TC描述都有对应代码实现。回标发现遗漏必须补齐。

#### 5.1 TC分类与生成策略

| 类别 | 策略 |
|------|------|
| A.基本功能 | 复用已有seq，设不同参数 |
| B.错误注入 | 新seq构造非法值，需绕过txn约束，错误响应按TB限制处理响应字段 |
| C.配置/模式 | test build_phase改config，run_phase操作VIF |
| D.时序/性能 | 配置agent delay，测响应时间 |
| E.FIFO/缓冲压力 | 配置agent大delay，多事务填满缓冲 |
| F.随机测试 | rand字段+constraint，repeat多次 |
| G.多事务序列 | body中多txn或test中连续start多seq |
| H.复位测试 | helper task+fork/join_any |

根据每个TC的描述内容，判断其属于哪一类，采用对应策略生成。

#### 5.2 代码生成规则

seq和test的代码模板及各场景模式详见 `references/testcase_patterns.md`，编码规范详见 `references/UVM_coding_style.md`。以下为生成时的核心约束：

- 绕过txn内建约束用 `txn.constraint_mode(0)`（构造非法值时必须）
- 数组字段大小须与对应长度字段匹配
- 不使用`uvm_do`宏，显式start_item/finish_item
- rand字段声明在new之前，constraint在rand之后
- 修改agent config必须在build_phase中super之后
- 复位操作使用base_test提供的helper task
- **package中不得使用层次引用**
- VIF操作通过config_db获取，不用层次路径
- **时序延迟用VIF周期计数(repeat(N) @(m_vif.cb))**，不用固定#delay，除非TC明确要求绝对时间
- **所有期望结果必须有检查代码**：txn.status检查、txn.rdata比对、VIF信号断言，用`uvm_error`报告不匹配
- **错误注入TC中txn.has_rdata必须设为0**（错误响应只返回8-bit status，无rdata）

#### 5.3 特殊场景识别

当TC描述涉及以下场景时，从 `references/testcase_patterns.md` 中选取对应模式：

| 场景关键词 | 对应模式 |
|------------|----------|
| 中止/abort/提前终止 | 协议帧中止模式 |
| 总线错误/error response | 总线错误注入模式 |
| 反压/backpressure/stall | 缓冲反压模式 |
| 随机/random | 随机测试模式 |
| 模式切换/切换配置 | 配置切换模式 |
| 属性验证/RO/RW/WC | 寄存器属性验证模式 |
| 运行中复位/mid-reset | 运行中复位模式 |

#### 5.4 TC代码生成后自检（强制）

**每个TC代码生成后，必须对照5.0映射表逐条回标自检**：

- 配置条件：每个配置项都有代码且与TC描述原文一致（非自行发挥）
- 激励步骤：每个步骤都有代码，无遗漏，时序用VIF周期计数
- 期望结果：每个期望都有`uvm_error`检查代码，不可只有激励无验证
- 覆盖率检查点：有对应覆盖方式
- 错误注入类has_rdata=0
- **零自行发挥**：代码逻辑必须严格对应TC描述原文，不可添加TC未要求的行为，不可省略TC要求的行为

**自检发现遗漏必须补齐后再输出。**

### 步骤6: 输出文件

所有新seq class追加到步骤3识别出的seq package文件（`endpackage`之前），所有新test class追加到test package文件（`endpackage`之前）。不创建额外文件或package。

**命名规则**（必须严格匹配Excel TC Name）：

| 命名对象 | 格式 | 说明 |
|----------|------|------|
| seq class | `<prefix>_<tc_name>_seq` | prefix从已有seq命名惯例提取 |
| test class | `test_<tc_name>` | 无前缀 |

输出完成后生成 `tc_mapping.md`：TC编号 | TC Name | seq类名 | test类名。

### 步骤6.5: TB限制动态分析（编译仿真后）

编译仿真后，根据实际失败结果补充TB限制记录。这是步骤3.1静态分析的必要补充——很多限制只有跑了才知道。

**流程**：
1. 编译/仿真某个TC后，如果出现超时、UVM_ERROR、UVM_FATAL等异常
2. 分析根因：是testcase代码问题还是TB基础设施限制
3. 如果是TB限制，记录到限制表中，包含：现象、根因、规避策略
4. 对尚未生成的TC，应用新的规避策略
5. 对已生成但受影响的TC，按新策略修正

**常见动态发现的限制类型**：

| 现象 | 可能的TB根因 | 分析方法 |
|------|-------------|----------|
| 仿真超时(PH_TIMEOUT) | driver在wait信号时卡死，无超时保护 | 查看driver的wait语句，确认是否有死等 |
| Monitor报解析异常 | monitor解析逻辑与DUT实际响应不匹配 | 对比DUT响应时序与monitor期望 |
| Monitor报"Frame too short" | monitor独立触发，快速模式下时序竞争 | 修改monitor为有状态追踪 |
| Monitor报"DUT stopped driving" | monitor在错误时序点捕获response | 修改monitor的response捕获时序 |
| 编译报层次引用错误 | package中使用了模块层次路径 | 改用VIF或helper task |
| objection未drop导致挂起 | fork/join_any后sequence卡住，disable fork不彻底 | 检查objection raise/drop配对 |

### 步骤7: 验证输出

- class名严格匹配Excel TC Name
- factory宏已注册（`uvm_object_utils` / `uvm_component_utils`）
- txn字段正确设置，错误注入类按TB限制处理响应字段
- 无层次引用、无语法错误
- 编码规范遵循 `references/UVM_coding_style.md`

### 步骤8: 编译仿真验证（推荐）

对生成的TC执行编译仿真：`cd <script_dir> && make clean && make sim TEST=test_<tc_name>`

0 UVM_ERROR/0 UVM_FATAL为通过；有ERROR则分析根因(TC代码问题→修改TC；TB限制→修复TB并记录)。

Verdi查看波形用`-dbdir`加载KDB：`verdi -sverilog -dbdir simv.daidir -ssf aplc_tb.fsdb -top <top> -nologo`
