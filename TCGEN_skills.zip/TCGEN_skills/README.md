# TCGEN_skills — UVM Testcase 自动生成器

根据 RTM 矩阵 Excel、RTL 代码、HLD 文档和 DV SPEC 文档，结合已有 UVM 验证环境，自动生成所有 testcase 的 SystemVerilog 代码。

## 怎么用

1. 在工作目录下准备 `input_config.json`，填入 4 个文件路径：

```json
{
    "rtm_excel": "/path/to/RTM.xlsx",
    "rtl_path":  "/path/to/rtl",
    "hld_doc":   "/path/to/HLD.md",
    "dv_spec":   "/path/to/DV_SPEC.md"
}
```

2. 在 Claude Code 中输入包含 `生成测试用例`、`生成testcase`、`生成TC` 等关键词的指令即可触发。

3. Skill 会依次执行 8 个步骤，其中 2 个节点需要你确认：
   - **步骤3.5**：TB 环境理解确认（确认提取的 txn/seq/test/driver 信息是否正确）
   - **步骤5**：逐 TC 的"描述→代码映射表"确认（确认后再写代码）

## 目录结构

```
TCGEN_skills/
├── SKILL.md                          # Skill 完整工作流定义（8 步流程 prompt）
├── README.md                         # 本文件
├── scripts/
│   ├── parse_rtm_tc.py              # 解析 RTM "DV Testcase List" sheet → JSON
│   └── parse_rtm_checker.py         # 解析 RTM "Checker List" sheet → JSON
├── references/
│   ├── input_config_template.json   # input_config.json 模板
│   ├── testcase_patterns.md         # 11 种 TC 代码模式模板
│   └── UVM_coding_style.md          # UVM 编码规范
└── output/
    └── tc_mapping.md                # 生成的 TC 映射表（TC编号 → seq → test）
```

## 产出物

| 产出 | 位置 | 说明 |
|------|------|------|
| seq 代码 | TB 的 `seq/<seq_pkg>.sv` | 追加到 `endpackage` 之前 |
| test 代码 | TB 的 `tc/<test_pkg>.sv` | 追加到 `endpackage` 之前 |
| TC 映射表 | `output/tc_mapping.md` | 不污染工作目录 |

## 核心设计

- **零硬编码**：所有模块特定信息从 TB 代码和文档动态提取，不硬编码到 skill 中
- **双重锁死**：写代码前输出映射表确认，写完后回标验证，确保 TC 描述零遗漏
- **严格映射**：代码逻辑严格对应 TC 描述原文，不可自行发挥

详细流程、分类策略、编码规则等见 `SKILL.md`。
